package com.example.latihan8_541231062_rafif_sqlite

import Helper.EXTRA_POSITION
import Helper.EXTRA_QUOTE
import android.os.Build.VERSION.SDK_INT
import android.os.Bundle
import android.os.Parcelable
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.latihan8_541231062_rafif_sqlite.data.Quote
import com.example.latihan8_541231062_rafif_sqlite.db.QuoteHelper
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers

class MainActivity : AppCompatActivity() {

    private val binding: ActivityMainBinding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }
    private lateinit var quoteHelper: QuoteHelper
    private lateinit var adapter: QuoteAdapter

    companion object {
        const val EXTRA_STATE = "EXTRA_STATE"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)

        // Inisialisasi RecyclerView
        setupRecyclerView()

        // Inisialisasi QuoteHelper
        quoteHelper = QuoteHelper.getInstance(applicationContext)

        if (savedInstanceState == null) {
            loadQuotes()
        } else {
            val list = savedInstanceState.parcelableArrayList<Quote>(EXTRA_STATE)
            if (list != null) {
                adapter.listQuotes = list
            }
        }
    }

    private fun setupRecyclerView() {
        binding.rvQuotes.layoutManager = LinearLayoutManager(this)
        binding.rvQuotes.setHasFixedSize(true)
        adapter = QuoteAdapter(object : QuoteAdapter.OnItemClickCallback {
            override fun onItemClicked(selectedQuote: Quote?, position: Int?) {
                val intent = Intent(this@MainActivity, QuoteAddUpdateActivity::class.java).apply {
                    putExtra(EXTRA_QUOTE, selectedQuote)
                    putExtra(EXTRA_POSITION, position)
                }
                resultLauncher.launch(intent)
            }
        })
        binding.rvQuotes.adapter = adapter
    }

    private inline fun <reified T : Parcelable> Bundle.parcelableArrayList(key: String): ArrayList<T>? =
        when {
            SDK_INT >= 33 -> getParcelableArrayList(key, T::class.java)
            else -> @Suppress("DEPRECATION") getParcelableArrayList(key)
        }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putParcelableArrayList(EXTRA_STATE, adapter.listQuotes)
    }

    private fun loadQuotes() {
        lifecycleScope.launch {
            binding.progressbar.visibility = View.VISIBLE
            val deferredQuotes = async(Dispatchers.IO) {
                quoteHelper.open()
                val cursor = quoteHelper.queryAll()
                val quotes = Helper.mapCursorToArrayList(cursor)
                quoteHelper.close()
                quotes
            }

            val quotes = deferredQuotes.await()
            binding.progressbar.visibility = View.INVISIBLE
            if (quotes.isNotEmpty()) {
                adapter.listQuotes = quotes
            } else {
                adapter.listQuotes = ArrayList()
                showSnackBarMessage("Tidak ada data saat ini")
            }
        }
    }

    private fun showSnackBarMessage(message: String) {
        Snackbar.make(binding.rvQuotes, message, Snackbar.LENGTH_SHORT).apply {
            setAction("OK") { dismiss() }
            show()
        }
    }
}