package com.example.latihan8_541231062_rafif_sqlite

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.latihan8_541231062_rafif_sqlite.data.Quote

class QuoteAdapter(private val onItemClickCallback: OnItemClickCallback) :
    RecyclerView.Adapter<QuoteAdapter.QuoteViewHolder>() {
    var listQuotes = ArrayList<Quote>()

    inner class QuoteViewHolder(private val binding: ItemQuoteBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(quote: Quote) {
            with(binding) {
                tvItemTitle.text = quote.title
                tvItemCategory.text = categoryList[quote.category.toString().toInt()]
                tvItemDescription.text = quote.description
                tvItemDate.text = quote.date
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuoteViewHolder {
        val binding = ItemQuoteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return QuoteViewHolder(binding)
    }

    override fun getItemCount(): Int = listQuotes.size

    override fun onBindViewHolder(holder: QuoteViewHolder, position: Int) {
        holder.bind(listQuotes[position])
    }

    interface OnItemClickCallback {
        fun onItemClicked(selectedNote: Quote?, position: Int?)
    }
}