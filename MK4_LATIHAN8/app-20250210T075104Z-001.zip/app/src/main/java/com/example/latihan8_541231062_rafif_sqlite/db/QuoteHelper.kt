package com.example.latihan8_541231062_rafif_sqlite.db

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.example.latihan8_541231062_rafif_sqlite.db.DatabaseContract.QuoteColumns.Companion.TABLE_QUOTE
import com.example.latihan8_541231062_rafif_sqlite.db.DatabaseContract.QuoteColumns.Companion._ID
import java.sql.SQLException

class QuoteHelper private constructor(context: Context) {
    companion object {
        private lateinit var dataBaseHelper: DatabaseHelper
        @Volatile
        private var INSTANCE: QuoteHelper? = null
        private lateinit var database: SQLiteDatabase

        fun getInstance(context: Context): QuoteHelper =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: QuoteHelper(context).also { INSTANCE = it }
            }
    }

    init {
        dataBaseHelper = DatabaseHelper(context)
    }

    @Throws(SQLException::class)
    fun open() {
        database = dataBaseHelper.writableDatabase
    }

    fun close() {
        if (database.isOpen) database.close()
        dataBaseHelper.close()
    }

    fun queryAll(): Cursor {
        return database.query(
            TABLE_QUOTE,
            null,
            null,
            null,
            null,
            null,
            "$_ID ASC" // Sorting
        )
    }

    fun queryById(id: String): Cursor {
        return database.query(
            TABLE_QUOTE,
            null,
            "$_ID = ?",
            arrayOf(id),
            null,
            null,
            null
        )
    }

    fun insert(values: ContentValues?): Long {
        return if (values != null) {
            database.insert(TABLE_QUOTE, null, values)
        } else {
            -1 // Return -1 to indicate failure
        }
    }

    fun update(id: String, values: ContentValues?): Int {
        return if (values != null) {
            database.update(TABLE_QUOTE, values, "$_ID = ?", arrayOf(id))
        } else {
            0 // Return 0 to indicate no rows were updated
        }
    }

    fun deleteById(id: String): Int {
        return database.delete(TABLE_QUOTE, "$_ID = ?", arrayOf(id))
    }
}